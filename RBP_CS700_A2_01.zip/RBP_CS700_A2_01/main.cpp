// main.cpp
// Author:    Rishi B. Patel (200529611)
// Date:      02/October/2024
/* Purpose:   This main.cpp contains functions, namely getStudInfo(), getMin_Marks(), getMax_Marks(),
              getAvg_Marks(), Letter_Grade(). They're used calculate minimum, maximum,and average marks.
              A grade is also assigned based on the aggregate marks scored by the student.
              It also contains main() function.
*/



#include <iostream>     // Used for including i/p & o/p stream library for operations like input (cin) and output (cout).
#include <fstream>      // Used for reading and writing from/to any file.
#include <iomanip>      // Used for manipulating the output.
#include "grades.h"     // Used for including the header file which has function declaration for getStudInfo(), getMin_Marks(), getMax_Marks(),getAvg_Marks(), Letter_Grade().

using namespace std;    // Used for removing the need to write std:: everytime before each cin, cout, string, etc.



// Function to process a student's data line and return necessary information.
// Creator:             Rishi B. Patel (200529611)
// Date of Creation:    02/October/2024
// Function Name:       getStudInfo()
/* Parameters:          There are 2 parameters. Both gives reference.
                        ifstream &input: Input file stream to read student data.
                        ofstream &output: Output file stream to write student data in formatted output.
*/
// Return:              Return type is void. None
/* Purpose:             From the i/p file, this function fetches the student's ID, the number of exams, and
                        the exam scores.
                        Afterwards it calculates the student's minimum marks, maximum marks, average marks,
                        and assigns a letter grade based.
                        Lastly, the output is student's information both to the console display and to the
                        output file.
*/
void getStudInfo(ifstream &input, ofstream &output)
{
    // This will take student ID and number of exams for each student from the input file.
    int i, stud_ID, no_of_exams;
    input >> stud_ID >> no_of_exams;

    // This will read the exam marks for all exams in an array.
    int scores[no_of_exams];
    for (i = 0; i < no_of_exams; ++i)
    {
        input >> scores[i];
    }

    // These functions are invoked for getting the min., max., avg. marks, and a letter grade for each and every student.
    int min_marks = getMin_Marks(scores, no_of_exams);
    int max_marks = getMax_Marks(scores, no_of_exams);
    double avg_marks = getAvg_Marks(scores, no_of_exams);
    string letterGrade = Letter_Grade(avg_marks);

    // For printing data on console display output
    cout << "Student ID: " << stud_ID << ", Min: " << min_marks << ", Max: " << max_marks
         << ", Average: " << fixed << setprecision(2) << avg_marks
         << ", Grade: " << letterGrade << ", Exams: " << no_of_exams << endl;

    // For writing the data to an output file which consists of Student ID, no. of exam, all exam marks, min. & max. exam marks, avg. exam marks, and a letter grade based on that average.
    output << left << setw(12) << stud_ID                           // Student ID
           << setw(12) << min_marks                                 // Min Marks
           << setw(12) << max_marks                                 // Max Marks
           << setw(12) << fixed << setprecision(2) << avg_marks     // Average Marks
           << setw(12) << letterGrade                               // Letter Grade
           << setw(12) << no_of_exams;                              // Number of Exams
    // This for loop will output the exam marks for the given student.
    for (i = 0; i < no_of_exams; ++i)
    {
        output << setw(5) << scores[i];                             // Exam Scores
    }
    output << endl;                                                 // Newline for each student.
}



// Function to calculate minimum score.
// Creator:             Rishi B. Patel (200529611)
// Date of Creation:    02/October/2024
// Function Name:       getMin_Marks()
/* Parameters:          int scores[]. This is array of int storing student's exam marks.
                        int size. For finding the no. of exams given by each student.
*/
// Return:              This func. will return minimum exam marks from the array.
/* Purpose:             The purpose of this func. is to compare each & every exam score of the student and
                        return the lowest marks.
*/
int getMin_Marks(int scores[], int size)
{
    // We take first entry as lowest marks and compare with other entries.
    int min_marks = scores[0];

    // Iterates all the entries to find the min. marks
    for (int i = 1; i < size; ++i)
    {
        if (scores[i] < min_marks)
        {
            min_marks = scores[i];  // Change min_marks if lower marks are found.
        }
    }
    return min_marks;               // Return the minimum marks
}



// Function to calculate maximum score.
// Creator:             Rishi B. Patel (200529611)
// Date of Creation:    02/October/2024
// Function Name:       getMax_Marks()
/* Parameters:          int scores[]. This is array of int storing student's exam marks.
                        int size. For finding the no. of exams given by each student.
*/
// Return:              This func. will return maximum exam marks from the array.
/* Purpose:             The purpose of this func. is to compare each & every exam score of the student and
                        return the highest marks.
*/
int getMax_Marks(int scores[], int size)
{
    // We take first entry as highest marks and compare with other entries.
    int max_marks = scores[0];

    // Iterates all the entries to find the max. marks
    for (int i = 1; i < size; ++i)
    {
        if (scores[i] > max_marks)
        {
            max_marks = scores[i];  // Change max_marks if higher marks are found.
        }
    }
    return max_marks;               // Return the minimum marks
}



// Function to calculate average score.
// Creator:             Rishi B. Patel (200529611)
// Date of Creation:    02/October/2024
// Function Name:       getAvg_Marks()
/* Parameters:          int scores[]. This is array of int storing student's exam marks.
                        int size. For finding the no. of exams given by each student.
*/
// Return:              This func. will return average exam marks from the array.
/* Purpose:             The purpose of this func. is to calculate each and every exam marks of a given student
                        and divide by the no. of attempts. This avg. will be used to assign a letter grade.
*/
double getAvg_Marks(int scores[], int size)
{
    // Initially set sum to 0.
    int sum = 0;
    double avg_score;

    // Iterate over the entire entries of marks and keep on adding them.
    for (int i = 0; i < size; ++i)
    {
        sum += scores[i];                           // All the exam marks are added to the sum total.
    }

    avg_score = static_cast<double>(sum) / size;    // Type Casting to get float answer. Divide sum total marks by no. of exam attempts.


    return avg_score;                               // Return the average score
}



// Function to assign letter grade based on average score.
// Creator:             Rishi B. Patel (200529611)
// Date of Creation:    02/October/2024
// Function Name:       Letter_Grade
// Parameters:          average_marks
// Return:              This function returns a string. A letter grade, like A, B, C, etc is returned.
/* Purpose:             The purpose of this func. is assign to letter grade to each and every student based
                        on the marks scored by the student.
*/
string Letter_Grade(double average_marks)
{
    // This is self-explanatory. If-else if is used to assign grade to the marks range.
    if (average_marks >= 95) return "A";
    else if (average_marks >= 91.67)
        return "A-";
    else if (average_marks >= 88.3)
        return "B+";
    else if (average_marks >= 85)
        return "B";
    else if (average_marks >= 81.67)
        return "B-";
    else if (average_marks >= 78.33)
        return "C+";
    else if (average_marks >= 75)
        return "C";
    else if (average_marks >= 71.67)
        return "C-";
    else if (average_marks >= 68.33)
        return "D+";
    else if (average_marks >= 65)
        return "D";
    else if (average_marks >= 61.67)
        return "D-";
    else
        return "F";
}



// Creator:             Rishi B. Patel (200529611)
// Date of Creation:    02/October/2024
// Function Name:       main()
// Parameters:          No parameters.
// Return:              Returns int 0 after successful execution
/* Purpose:             Used to open the input file (grades.txt) and output file (output.txt).
                        Used to write a header section to the output file, get each student's data by calling the getStudInfo function,
                        and then writing the processed information to both the console and the output file.

*/
int main()
{
    ifstream ipFile("grades.txt");      // Input file stream
    ofstream opFile("output.txt");      // Output file stream


    // To check if i/p file is opened properly
    if (!ipFile)
    {
        cerr << "Error opening input file!" << endl;
        return 1;                       // Returns 1 if i/p file can't be opened
    }

    // To check if o/p file is opened properly
    if (!opFile)
    {
        cerr << "Error opening output file!" << endl;
        return 1;                       // Returns 1 if o/p file can't be opened
    }

    // Writing the header section line to the output file
    opFile << left << setw(12) << "Student ID"
           << setw(12)  << "Min_Marks"
           << setw(12)  << "Max_Marks"
           << setw(12) << "Average"
           << setw(12)  << "Grade"
           << setw(12)  << "Exams"
           << "Exam Marks" << endl;

    // Process every student data
    while (!ipFile.eof())
    {
        getStudInfo(ipFile, opFile);    // Func. call to get each and every student's data
    }

    ipFile.close();
    opFile.close();

    return 0;
}
