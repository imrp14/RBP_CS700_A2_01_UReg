// grades.h
// Author: Rishi B. Patel (200529611)
// Date: 02/October/2024
// Purpose: This header file contains the function declarations. It is used to get student grade data including calculating min, max, average scores,
//          and letter grade assignment.



#ifndef GRADES_H        // ifndef: if not defined, to check if macro is non-existent.
#define GRADES_H        // define: used to define the macros

#include <fstream>      // Used for reading and writing from/to any file.
#include <string>       // For using strings

using namespace std;    // Used for removing the need to write std:: everytime before each cin, cout, string, etc.




// Function to process a student's data line and return necessary information.
// Creator:             Rishi B. Patel (200529611)
// Date of Creation:    02/October/2024
// Function Name:       getStudInfo()
/* Parameters:          There are 2 parameters. Both gives reference.
                        ifstream &input: Input file stream to read student data.
                        ofstream &output: Output file stream to write student data in formatted output.
*/
// Return:              Return type is void. None
/* Purpose:             From the i/p file, this function fetches the student's ID, the number of exams, and
                        the exam scores.
                        Afterwards it calculates the student's minimum marks, maximum marks, average marks,
                        and assigns a letter grade based.
                        Lastly, the output is student's information both to the console display and to the
                        output file.
*/
void getStudInfo(ifstream &input, ofstream &output);



// Function to calculate minimum score.
// Creator:             Rishi B. Patel (200529611)
// Date of Creation:    02/October/2024
// Function Name:       getMin_Marks()
/* Parameters:          int scores[]. This is array of int storing student's exam marks.
                        int size. For finding the no. of exams given by each student.
*/
// Return:              This func. will return minimum exam marks from the array.
/* Purpose:             The purpose of this func. is to compare each & every exam score of the student and
                        return the lowest marks.
*/
int getMin_Marks(int scores[], int size);



// Function to calculate maximum score.
// Creator:             Rishi B. Patel (200529611)
// Date of Creation:    02/October/2024
// Function Name:       getMax_Marks()
/* Parameters:          int scores[]. This is array of int storing student's exam marks.
                        int size. For finding the no. of exams given by each student.
*/
// Return:              This func. will return maximum exam marks from the array.
/* Purpose:             The purpose of this func. is to compare each & every exam score of the student and
                        return the highest marks.
*/
int getMax_Marks(int scores[], int size);



// Function to calculate average score.
// Creator:             Rishi B. Patel (200529611)
// Date of Creation:    02/October/2024
// Function Name:       getAvg_Marks()
/* Parameters:          int scores[]. This is array of int storing student's exam marks.
                        int size. For finding the no. of exams given by each student.
*/
// Return:              This func. will return average exam marks from the array.
/* Purpose:             The purpose of this func. is to calculate each and every exam marks of a given student
                        and divide by the no. of attempts. This avg. will be used to assign a letter grade.
*/
double getAvg_Marks(int scores[], int size);




// Function to assign letter grade based on average score.
// Creator:             Rishi B. Patel (200529611)
// Date of Creation:    02/October/2024
// Function Name:       Letter_Grade
// Parameters:          average_marks
// Return:              This function returns a string. A letter grade, like A, B, C, etc is returned.
/* Purpose:             The purpose of this func. is assign to letter grade to each and every student based
                        on the marks scored by the student.
*/
string Letter_Grade(double average_marks);

#endif // STUDENT_GRADE_PROCESSOR_H
