# CS-700-ASSIGNMENT-2.1	Student Grade Assignment



## CREATOR
Rishi B Patel 



## ID NUMBER
200529611



## EXPLANATION
This program is used to read students' grades data including student id, no. of attempts, and marks scored in each exam.
This program calculates the minimum, maximum, and average marks for each and every student.
Based on this avg marks, a letter grade is assigned to every student. 
Letter Grade Percentage
A 		95%–100%
A- 		91.67%–95%
B+ 		88.3%–91.67%
B 		85%–88.3%
B- 		81.67%–85%
C+		78.33%–81.67%
C 		75%–78.33%
C- 		71.67%–75%
D+ 		68.33%–71.67%
D 		65%–68.33%
D- 		61.67%–65%
F 		0%–61.67%




## Features
* Reads students' entire data from input file.
* Calculates min., max, avg. marks. and assigns letter grade.
* Outputs results to both console display and an output file.




## INPUT:	Each line of grades.txt file. Contains Student's IDs, followed by the no. of exams taken by each student and the scores achieved in those exams.



## OUTPUT:	Console Display: 	Student ID, min. marks, max. marks, and avg. marks, and a letter grade.
		Output File (.txt): 	Student ID, no. of exams taken, all exams marks, min. marks, max. marks, and avg. marks, and a letter grade.


## COMPILATION AND EXECUTION

### FILES
	main.cpp:			Source code file with all the logical implementation. This contains function definitions.
	grades.h:			This is a header and it  contains function declarations.
	grades.txt:			Input file from which data is read.
	output.txt:			Output file where all data is stored.

I have used CodeBlocks IDE and it has a built-in compiler for C/C++.
To build and run the program, upload all the files and press on build and run icon in the IDE. There's no need for writing the commands on the terminal.
Upon succesful execution, the output will be displayed to a console display as well as an output file will be created.



## TEST OUTPUTS
Student ID  Min_Marks   Max_Marks   Average     Grade       Exams       Exam Marks
584827925   71          100         93.27       A-          11          100  88   95   94   98   100  90   71   100  92   98   
952344495   68          100         84.64       B-          11          78   83   92   76   83   88   93   100  68   100  70

